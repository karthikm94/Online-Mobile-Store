package com.mobile.application.controller;

import java.util.ArrayList;
import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.servlet.ModelAndView;

//import com.mobile.application.model.HeadSet;
import com.mobile.application.model.Image;
import com.mobile.application.model.Item;
//import com.mobile.application.model.PowerBank;
//import com.mobile.application.repository.HeadSetRepository;
import com.mobile.application.repository.ItemRepository;

@Controller

public class AccessoriesController {

	private static final int THIRTEEN = 13;
	private static final int TWELVE = 12;
	private static final int FOURTEEN = 14;
	private static final int SIXTEEN = 16;
	private static final int FIFTEEN = 15;
	private static final int ELEVEN = 11;
	private static final int TWENTYTWO = 22;
	private static final int TWENTYONE = 21;
	private static final int TWENTY = 20;
	private static final int NINETEEN = 19;
	private static final int EIGHTEEN = 18;
	private static final int SEVENTEEN = 17;
	@Autowired
	private ItemRepository itemRepository;

	// to add the products
	@PostMapping("/saveaccess")
	public String saveaccess(Item item) {

		itemRepository.save(item);
		return "accessories";
	}

	Image image;

	@RequestMapping("/access")
	public String access() {
		return "/access";
	}

	@RequestMapping("/addaccess")
	public String addaccess() {
		return "/addaccess";
	}

	// For power banks
	@PostMapping("/view-power")
	public ModelAndView power() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = SEVENTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Power Bank" + exception);
		}
		return modelObject;
	}

	// For Head sets
	@PostMapping("/view-headset")
	public ModelAndView headset() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = EIGHTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Head Set" + exception);
		}
		return modelObject;
	}

	// For chargers
	@PostMapping("/view-charger")
	public ModelAndView charger() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productID = NINETEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productID)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Chargers" + exception);
		}
		return modelObject;
	}

	// For mobile Covers

	@PostMapping("/view-cover")
	public ModelAndView cover() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = TWENTY;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Mobile covers" + exception);
		}
		return modelObject;
	}

	// For Mobile Screen
	@PostMapping("/view-screen")
	public ModelAndView screen() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = TWENTYONE;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Mobile Screens" + exception);
		}
		return modelObject;
	}

	// For USB
	@PostMapping("/view-usb")
	public ModelAndView usb() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = TWENTYTWO;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in USB" + exception);
		}
		return modelObject;
	}
//end of accessory

	// For Mobile Brands
	// For Apple phones
	@PostMapping("/apple")
	public ModelAndView apple() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = ELEVEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Apple phone" + exception);
		}
		return modelObject;
	}

	// for Vivo phones
	@PostMapping("/vivo")
	public ModelAndView vivo() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = FIFTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}

			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Vivo Phone" + exception);
		}
		return modelObject;
	}

	// for Real Me phones
	@PostMapping("/realme")

	public ModelAndView realme() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = SIXTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in RealMe Phone" + exception);
		}
		return modelObject;
	}

	// For one Plus
	@PostMapping("/oneplus")
	public ModelAndView oneplus() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = FOURTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in One Plus Phone" + exception);
		}
		return modelObject;
	}

	// For Samsung phones
	@PostMapping("/samsung")
	public ModelAndView samsung() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = TWELVE;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in Samsung Phone" + exception);
		}
		return modelObject;
	}

	// For MI phones
	@PostMapping("/mi")
	public ModelAndView mi() {
		ModelAndView modelObject = new ModelAndView("accessview");
		try {
			List<Item> itemValue = (List<Item>) itemRepository.findAll();
			List<Item> item = new ArrayList<>();
			int productId = THIRTEEN;
			for (var iterate : itemValue) {
				if (iterate.getProductid() == (productId)) {
					item.add(iterate);
				}
			}
			modelObject.addObject("list", item);
		} catch (Exception exception) {
			System.out.println("Exception in MI Phone" + exception);
		}
		return modelObject;
	}

}
